//LIMIT REQUEST API PER 15 MENIT
export const LIMIT_USER = 10

export const LIMIT_MEMBER = 20

export const LIMIT_PREMIUM = 50