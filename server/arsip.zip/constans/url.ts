const KOMIKINDO_URL: string = "https://komikindo.tv"
const PROXY = "https://cfv7gd.deta.dev/?url="
const BASE_URL: string= KOMIKINDO_URL
export default BASE_URL