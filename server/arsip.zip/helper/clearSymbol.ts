export const clear = (string:string):string =>{
  return string.trim().replace(/\n/g,' ')
}